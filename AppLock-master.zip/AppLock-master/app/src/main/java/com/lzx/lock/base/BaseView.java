package com.lzx.lock.base;


public interface BaseView<T extends BasePresenter> {
}
